"""Version of pi_heif/pi_heif."""

__version__ = "0.21.0"
