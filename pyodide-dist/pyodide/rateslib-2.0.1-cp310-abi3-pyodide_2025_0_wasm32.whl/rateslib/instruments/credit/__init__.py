from rateslib.instruments.credit.derivatives import CDS

__all__ = ["CDS"]
