from __future__ import annotations

from river.base.base import log_method_calls

__all__ = ["log_method_calls"]
