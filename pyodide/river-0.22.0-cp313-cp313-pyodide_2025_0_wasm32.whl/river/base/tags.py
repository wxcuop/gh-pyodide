from __future__ import annotations

TEXT_INPUT = "text input"
POSITIVE_INPUT = "positive input"
