
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.6.3'
version = '1.6.3'
full_version = '1.6.3'
git_revision = 'da4443a'
commit_count = 'da4443a'
release = True
if not release:
    version = full_version
