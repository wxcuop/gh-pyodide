TRUE_VALUES = ["yes", "true", "on", "1", "y"]

FALSE_VALUES = ["no", "false", "off", "0", "n"]

BOOL_VALUES = TRUE_VALUES + FALSE_VALUES

REGEXES = {
    "email": r".+?\@.+?",
}
